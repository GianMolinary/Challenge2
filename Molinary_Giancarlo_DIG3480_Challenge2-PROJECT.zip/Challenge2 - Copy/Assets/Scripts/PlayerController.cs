﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    private Rigidbody2D rb2d;
    public float speed;
    public float jumpForce;
    private int count;
    private int lives;
    public Text countText;
    public Text winText;
    public Text livesText;
    public Text gameOverText;
    public AudioClip musicClipOne;
    public AudioClip musicClipTwo;
    public AudioSource musicSource;

    // Use this for initialization
    void Start() {

        rb2d = GetComponent<Rigidbody2D>();
        count = 0;
        lives = 3;
        winText.text = "";
        gameOverText.text = "";
        SetCountText();
        SetLivesText();
        GameOver();
    }

    // Update is called once per frame
    void Update()
    {

        float moveHorizontal = Input.GetAxis("Horizontal");

        Vector2 movement = new Vector2(moveHorizontal, 0);

        rb2d.AddForce(movement * speed);

        Vector3 pos = transform.position;
        pos.z = 0;
        transform.position = pos;

        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
    }
    

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag ("PickUp"))
        {
            other.gameObject.SetActive (false);
            count = count + 1;
            SetCountText ();
        }
        if (count >= 4)
        {
            musicSource.clip = musicClipOne;
            musicSource.Play();
        }
       



        if (other.gameObject.CompareTag ("Enemy"))
        {
            other.gameObject.SetActive (false);
            lives = lives - 1;
            SetLivesText ();
        }
       if (lives <= 0)
        {
            musicSource.clip = musicClipTwo;
            musicSource.Play();
            if (Input.GetKey("escape"))
            {
                Application.Quit();
            }
        }






        {
        
            if (lives <= 0)
            {
                rb2d.gameObject.SetActive (false);

                gameOverText.text = "Game Over";
                if (Input.GetKey("escape"))
                {
                    Application.Quit();
                }
            }

            SetLivesText();
        }

    }



    void SetCountText ()
    {
        countText.text = "Count: " + count.ToString ();
        if (count >= 4)
        {
            winText.text = "You Win!";
        }
    
    }

    void SetLivesText ()
    {
        livesText.text = "Lives: " + lives.ToString();
        
    }

    void GameOver()
    {
        if (lives >= 0)
        {
            GameOver();
        }
        gameOverText.text = "Game Over";
        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
    }


    void OnCollisionStay2D(Collision2D collision)
    {
        if(collision.collider.tag == "Ground") {

            if(Input.GetKey(KeyCode.UpArrow)) {

                rb2d.AddForce(new Vector2(0, jumpForce), ForceMode2D.Impulse);

            }
        }
    }

   

}
