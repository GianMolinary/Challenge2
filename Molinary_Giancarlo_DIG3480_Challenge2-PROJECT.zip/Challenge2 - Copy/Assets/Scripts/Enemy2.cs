﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2 : MonoBehaviour {

    // Use this for initialization
    void Start()
    {

    }

    Vector2 pointA = new Vector2(-25, 8);
    Vector2 pointB = new Vector2(-1, 8);


    // Update is called once per frame
    void Update()
    {
        transform.position = Vector2.Lerp(pointA, pointB, Mathf.PingPong(Time.time, 1));
    }

}
