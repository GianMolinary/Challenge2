﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy3 : MonoBehaviour {

    // Use this for initialization
    void Start()
    {

    }

    Vector2 pointA = new Vector2(5, -2);
    Vector2 pointB = new Vector2(1, -2);


    // Update is called once per frame
    void Update()
    {
        transform.position = Vector2.Lerp(pointA, pointB, Mathf.PingPong(Time.time, 1));
    }

}
